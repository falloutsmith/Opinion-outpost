$(document).ready(function() {
	$('.tabs a').click(function() {
		var $this = $(this);
		$('.panel').hide();
		$('.tabs a.active').removeClass('active');
		$this.addClass('active').blur();
		var panel = $this.attr('href');
		$(panel).fadeIn(550);
	}); // end click
	$('.panel').hide();
}); //end ready